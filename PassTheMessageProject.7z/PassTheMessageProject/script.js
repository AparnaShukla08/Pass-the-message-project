 const msginput= document.getElementById('msg');

 function sendMessage(){
    document.getElementById('message_output').innerHTML=msginput.value; // TO take value from input field and pass 
    msginput.value=" ";  // To make the input field blank again
 }